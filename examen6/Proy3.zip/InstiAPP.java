import java.util.Scanner;

//Antonio Vicente MOlines Martin 1DAM

public class InstiAPP {
    //número máximo de estudiantes por aula
    public static int maxEstudiantes = 30;
    //arrays de estudiantes
    public static Estudiante[] _1DAM = new Estudiante[maxEstudiantes];
    public static Estudiante[] _2DAM = new Estudiante[maxEstudiantes];


    

    


}
