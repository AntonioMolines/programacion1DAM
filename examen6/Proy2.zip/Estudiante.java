//Antonio Vicente Molines Martin 1DAM

public class Estudiante {

    //Atributos
    private String nombre;
    private String apellidos;
    private int anyo;
    private String DNI;
    private double notaMedia;

    //constructores

    public Estudiante(String nombre, String apellidos, int anyo, String DNI, double notaMedia) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        //comprobacion año
        if(anyo <= 2009 && anyo >= 1900) {
            this.anyo = anyo;
        }
        //si el año no es válido se crea con un valor por defecto para no tener que crear otro de 0 reintroduciendo todos los datos
        else {
            this.anyo = 2009;
            System.out.println("El valor de año introducido no es válido. Se creará un estudiante nacido en 2009. Si desea puede cambiar más tarde este valor");
        }
        this.DNI = DNI;
        //comprobación nota media
        if(notaMedia <= 10 && notaMedia >= 0) {
            this.notaMedia = notaMedia;
        }
        //igual que con año, se dará un valor por defecto si no se introduce una nota válida
        else {
            this.notaMedia = 5.0;
            System.out.println("El valor de la nota media introducido no es válido. Se pondrá un 5.0 de nota por defecto que podrá modificar más tarde.");
        }
    }

    //getters y setters

    public int getAnyo() {
        return anyo;
    }

    public void setAnyo(int anyo) {
        //comprobación de año
        if(anyo <= 2009 && anyo >= 1900) {
            this.anyo = anyo;
        }
        //como ya tiene valor, en vez de asignar uno por defecto, conservará el actual
        else {
            System.out.println("Valor no válido. El año debe de estar entre 1900 y 2009.");
        }
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String dNI) {
        DNI = dNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public void setNotaMedia(double notaMedia) {
        //comprobación de nota media
        if(notaMedia <= 10 && notaMedia >= 0) {
            this.notaMedia = notaMedia;
        }
        //como ya tiene valor, en vez de asignar uno por defecto, conservará el actual
        else {
            System.out.println("Valor no válido. La nota debe de estar entre 0.0 y 10.0.");
        }
    }

    //otros métodos

    public void imprimeInfo() {
        System.out.println("Alumno/a: " + nombre + " " + apellidos);
        System.out.println("DNI: " + DNI);
        int edad = 2023 - anyo;
        System.out.println("Edad: " + edad);
        System.out.println("Nota media: " + notaMedia);
    }
    
}
